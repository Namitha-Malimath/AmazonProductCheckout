package pages;

import com.aventstack.extentreports.ExtentTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.WebDriver;
import wrapper.CommonClass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/***
 * @author Namitha
 */
public class CartPage extends CommonClass {

    private static Properties prop;

    AndroidDriver driver;
    private String path = "//locators/CartPage.properties";

    /***
     * constructor to initiate driver and reports
     * @param ldriver - initiate driver
     * @param lTest - initiate report
     */
    public CartPage(AndroidDriver ldriver, ExtentTest lTest){
        this.driver = ldriver;
        this.test = lTest;
        prop = new Properties();
        try{
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+path);
            prop.load(fs);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /***
     * validate Product name
     */
    private void validateProductName(){
        String product_Name = getText(prop.getProperty("productName"));
    }

    /**
     * validate quantity of product
     */
    private void validateProductCount(){
        String product_Quantity = getText(prop.getProperty("productQuantity"));
    }

    /**
     * Click on proceed to checkout button
     */
    private void clickCheckoutButton(){
       elementClick(prop.getProperty("ButtonCheckOut"),"Proceed to Checkout button");
    }

    /**
     * validate cart page and click on proceed to checkout
     */
    public void cartItem(){
        validateProductName();
        validateProductCount();
        clickCheckoutButton();
    }
}
