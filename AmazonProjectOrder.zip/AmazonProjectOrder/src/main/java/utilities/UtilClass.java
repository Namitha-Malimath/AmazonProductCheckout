package utilities;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * @author Namitha
 */
public class UtilClass extends ReportClass{

    public static AndroidDriver driver;

    public String readConfigFile(String key){
        Properties p = new Properties();
        try {
            FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"/Config.properties");
            p.load(fs);
            return (String)p.get(key);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Launches the application
     */
    @BeforeSuite
    public void Setup(){
        startResult();
        DesiredCapabilities cab = new DesiredCapabilities();

        String os_Type = readConfigFile("OS_TYPE");
        String os_version = readConfigFile("OS_VERSION");
        String device_Name = readConfigFile("DEVICE_NAME");
        //String path = readConfigFile("PATH");

        cab.setCapability("platformName",os_Type);
        cab.setCapability("platformVersion",os_version);
        cab.setCapability("app","C:\\Users\\91913\\Downloads\\Amazon_shopping.apk");
        cab.setCapability("appPackage","com.amazon.mShop.android.shopping");
        cab.setCapability("appActivity","com.amazon.mShop.home.HomeActivity");
        //cab.setCapability("automationName","uiautomator2");

        try {
            driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),cab);
            driver.manage().timeouts().implicitlyWait(30, SECONDS);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Closes the application
     */
    public void closeApp(){
        driver.quit();
    }

    /**
     * EndSuite
     */
    @AfterSuite
    public void endSuite(){
        closeApp();
        endResult();
    }

    /**
     * identify element using locator
     * @param property
     * @return
     */
    public AndroidElement getLocator(String property){
        String locator = property;
        String locatorType = locator.split(">")[0];
        String locatorValue = locator.split(">")[1];
        WebElement locatedEle = null;
        if(locatorType.equalsIgnoreCase("id")){
            locatedEle = driver.findElement(By.id(locatorValue));
            return (AndroidElement) locatedEle;
        }else if(locatorType.equalsIgnoreCase("xpath")){
            locatedEle = driver.findElement(By.xpath(locatorValue));
            return (AndroidElement) locatedEle;
        }else if(locatorType.equalsIgnoreCase("name")){
            locatedEle = driver.findElement(By.name(locatorValue));
            return (AndroidElement) locatedEle;
        } else {
            return null;
        }
    }

    /**
     * List of web elements
     * @param property
     * @return
     */
    public List<AndroidElement> getElements(String property){
        String locator = property;
        String locatorType = locator.split(">")[0];
        String locatorValue = locator.split(">")[1];
        List<AndroidElement> elements = null;
        if(locatorType.equalsIgnoreCase("id")){
            elements = driver.findElements(By.id(locatorValue));
            return elements;
        }else if(locatorType.equalsIgnoreCase("xpath")){
            elements = driver.findElements(By.xpath(locatorValue));
            return elements;
        }else if(locatorType.equalsIgnoreCase("name")){
            elements = driver.findElements(By.name(locatorValue));
            return elements;
        } else {
            return null;
        }
    }

    /**
     * wait for element present
     */
    public void waitForElement(){
        driver.manage().timeouts().implicitlyWait(30,SECONDS);
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
                .withTimeout(30,SECONDS)
                .pollingEvery(5,SECONDS)
                .ignoring(NoSuchElementException.class);
    }


    /**
     * wait for element to be clickable
     * @param element
     */
    public void waitForElementClickable(WebElement element){
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * wait for element to be clickable
     * @param element
     */
    public void waitForElementPresent(WebElement element){
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * Captured screenshots
     *
     * @return
     */
    public String getScreenshot()
    {
        TakesScreenshot ts=(TakesScreenshot) driver;
        File src=ts.getScreenshotAs(OutputType.FILE);
        String path=System.getProperty("user.dir")+"/reports/screenshots/"+System.currentTimeMillis()+".jpeg";
        File destination=new File(path);
        try
        {
            FileUtils.copyFile(src, destination);
        } catch (IOException e)
        {
            System.out.println("Capture Failed "+e.getMessage());
        }
        return path;
    }

    public void reportLog(String message, String status){
        if(status.equalsIgnoreCase("INFO")) {
            test.log(Status.INFO, message);
        }else if(status.equalsIgnoreCase("FAIL")){
            test.log(Status.FAIL,message);
            try {
                String screenshotPath = getScreenshot();
                //To add it in the extent report
                test.fail("Test Case Failed Snapshot is below " + test.addScreenCaptureFromPath(screenshotPath));
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if(status.equalsIgnoreCase("PASS")){
            test.log(Status.PASS,message);
        }
    }

    @AfterMethod
    public void getResult(ITestResult result) throws Exception{
        if(result.getStatus() == ITestResult.FAILURE){
            //MarkupHelper is used to display the output in different colors
            test.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
            test.log(Status.FAIL, MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));
            //To capture screenshot path and store the path of the screenshot in the string "screenshotPath"
            //We do pass the path captured by this method in to the extent reports using "logger.addScreenCapture" method.
            //String Scrnshot=TakeScreenshot.captuerScreenshot(driver,"TestCaseFailed");
            String screenshotPath = getScreenshot();
            //To add it in the extent report
            test.fail("Test Case Failed Snapshot is below " + test.addScreenCaptureFromPath(screenshotPath));
        }
        else if(result.getStatus() == ITestResult.SKIP){
            test.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.ORANGE));
        }
        else if(result.getStatus() == ITestResult.SUCCESS)
        {
            test.log(Status.PASS, MarkupHelper.createLabel(result.getName()+" Test Case PASSED", ExtentColor.GREEN));
        }
        // driver.quit();
    }

}
