package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.testng.ITestResult;

import java.io.File;

/***
 * @author Namitha
 */
public class ReportClass {
    
    public ExtentTest test;
    public static ExtentReports extent;

    /**
     * @return Initializes the extent test report
     */
    public ExtentReports startResult(){
        ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/Result.html");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
       // extent.loadConfig(new File("./src/main/resources/extent-config.xml"));
        test = extent.createTest("Amazon order");
        
        return extent;
    }

    /**
     * ends result
     */
    public void endResult(){

        extent.flush();
    }
}
