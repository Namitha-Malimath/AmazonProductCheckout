package test;

import io.appium.java_client.android.AndroidDriver;
import org.testng.annotations.Test;
import pages.*;
import utilities.UtilClass;

/**
 * @author Namitha
 */
public class ProductCheckout extends UtilClass {

    @Test
    public void TestCase1(){
        LoginPage loginPage = new LoginPage(driver,test);
        loginPage.validateAndSelectSkipLogin();

        HomePage homePage = new HomePage(driver,test);
        homePage.searchAndSelectProduct();

        LocationDetailPage locationDetailPage = new LocationDetailPage(driver,test);
        locationDetailPage.location_details();

        ProductDetailsPage productDetailsPage = new ProductDetailsPage(driver,test);
        productDetailsPage.verifyProductDetailsAndAddToCart();

        CartPage cartPage = new CartPage(driver,test);
        cartPage.cartItem();
    }
}
