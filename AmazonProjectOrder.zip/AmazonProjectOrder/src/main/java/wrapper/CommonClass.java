package wrapper;

import io.appium.java_client.android.AndroidElement;
import org.junit.Assert;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import utilities.UtilClass;

import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.SECONDS;

/***
 *
 * @author Namitha
 */
public class CommonClass extends UtilClass {

    public void elementClick(String property, String message){
        AndroidElement element = getLocator(property);
        try{
            waitForElementClickable(element);
            element.click();
            System.out.println(message + " element is clicked");
            reportLog(message + " element is clicked","PASS");
        }catch (ElementNotVisibleException e){
            Assert.assertTrue(e.getMessage(), false);
        }catch (ElementNotInteractableException e){
            Assert.assertTrue(e.getMessage(),false);
        }catch (Exception e){
            Assert.assertTrue(e.getMessage(),false);
        }
    }
    public void enterText(String property, String message){
        AndroidElement element = getLocator(property);
        boolean flag = false;
        int count = 1;
        try{
            waitForElement();
            element.click();
           /* do{*/
                Thread.sleep(2000);
                waitForElement();
                driver.manage().timeouts().implicitlyWait(30,SECONDS);
                /*element.clear();
                element.sendKeys(message);*/
               /* flag = true;
                count++;*/
                reportLog(message + " is entered", "PASS");
                System.out.println(message + "entered");
           /* }while(flag=true || count>=10);*/
        }catch (ElementNotVisibleException e){
            Assert.assertTrue(e.getMessage(), false);
        }catch (ElementNotInteractableException e){
            Assert.assertTrue(e.getMessage(),false);
        }catch (Exception e){
            Assert.assertTrue(e.getMessage(),false);
        }
    }

    public void verifyElementDisplayed(String property, String message){
        AndroidElement element = getLocator(property);
        try{
            waitForElement();
            element.isDisplayed();
            System.out.println(message + "element is displayed");
            reportLog(message + " element is displayed","PASS");
        }catch (ElementNotVisibleException e){
            Assert.assertTrue(e.getMessage(), false);
        }catch (ElementNotInteractableException e){
            Assert.assertTrue(e.getMessage(),false);
        }catch (Exception e){
            Assert.assertTrue(e.getMessage(),false);
        }
    }

    public void generateAndClickRandom(String property,String message){
        int ran_Num = 0, ele_Size = 0;
        Random random = new Random();
        WebElement element = null;

        ele_Size = getElements(property).size();
        ran_Num = random.nextInt(ele_Size);
        try{
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            element = getElements(property).get(ran_Num);
            element.click();
            reportLog(message + " random element is clicked","PASS");
            System.out.println(message);
        }catch (ElementNotVisibleException e){
            Assert.assertTrue(e.getMessage(), false);
        }catch (ElementNotInteractableException e){
            Assert.assertTrue(e.getMessage(),false);
        }catch (Exception e){
            Assert.assertTrue(e.getMessage(),false);
        }
    }

    public void scrollToElement(){
        JavascriptExecutor js = (JavascriptExecutor) driver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "down");
        js.executeScript("mobile: scroll", scrollObject);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public boolean verifyElement(String property){
        driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
        boolean present = true;
        try{
            getLocator(property);
            return present;
        }catch (Exception e){
            present = false;
            e.printStackTrace();
            return present;
        }
    }

    public String getText(String property) {
        AndroidElement element = getLocator(property);
        String text = null;
        try {
            text = element.getText();

        }catch (ElementNotVisibleException e){
            Assert.assertTrue(e.getMessage(), false);
        }catch(ElementNotInteractableException e){
            Assert.assertTrue(e.getMessage(), false);
        }catch(Exception e){
            Assert.assertTrue(e.getMessage(), false);
        }
        return text;
    }

    public void enterTextJavascript(String property,String message){
        AndroidElement element = getLocator(property);
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("arguments[0].value='"+ message +"';", element);

    }
}

